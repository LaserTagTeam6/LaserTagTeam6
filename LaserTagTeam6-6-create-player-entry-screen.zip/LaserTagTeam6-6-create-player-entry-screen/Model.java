/*
Name: Team 6
Project: Laser Tag
Date: 09/30/2022
*/
class Model
{

	Model()
	{
	}

	public void update(){
	}
}
